package LWP;

our $VERSION = '6.24';

require LWP::UserAgent;  # this should load everything you need

sub Version { $VERSION; }

1;

__END__

#line 672
